/* 
 * File:   desc_include.h
 * Author: trbot
 *
 * Created on February 4, 2017, 5:20 AM
 */

#ifndef DESC_INCLUDE_H
#define	DESC_INCLUDE_H

/**
 * NOTE: THIS IS THE FILE TO INCLUDE, IF YOU WANT TO USE THE COUNTERS.
 */

#include "debugcounters_cpp.h"
//#include "threadcounters.h"

#endif	/* DESC_INCLUDE_H */

