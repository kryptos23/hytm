#!/bin/bash

makefileSuffix="_p8"
source build.inc.sh