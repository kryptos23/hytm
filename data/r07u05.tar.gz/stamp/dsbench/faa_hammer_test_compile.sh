#!/bin/sh

infile="faa_hammer_test.cpp ../lib/thread.c" ; g++ -std=c++0x -DPHYSICAL_PROCESSORS=192 -DDS_DEBUG=if\(0\) -DDS_DEBUG1=if\(0\) -DDS_DEBUG2=if\(0\) -DVERBOSE=if\(0\) -O3 -DTHREAD_BINDING=SOSCIP_SCATTER $infile -lpthread
