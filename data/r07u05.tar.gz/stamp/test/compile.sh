#!/bin/sh

g++ -std=c++0x -g -DPHYSICAL_PROCESSORS=192 -DDS_DEBUG=if\(0\) -DDS_DEBUG1=if\(0\) -DDS_DEBUG2=if\(0\) -DVERBOSE=if\(0\) -O1 suspended_data.cpp
