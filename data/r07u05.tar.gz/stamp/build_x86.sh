#!/bin/bash

makefileSuffix=""
xflags1=-mx32
source build.inc.sh